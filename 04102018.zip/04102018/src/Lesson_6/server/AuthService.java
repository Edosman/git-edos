package Lesson_6.server;

import java.sql.*;

public class AuthService {
    private static Connection connection;
    private static Statement stmt;

    public static void connect() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:mainDB25102018.db");
            stmt = connection.createStatement();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void addUsers(String login, String pass, String nick) throws SQLException {
        String sql = String.format("INSERT INTO USERS (login, password, nickname)" +
                "VALUES ('%s','%s','%s')", login, pass.hashCode(), nick);
        stmt.execute(sql);
    }

    public static String getNickByLoginAndPass(String login, String pass) {
        String sql = String.format("SELECT nickname, password FROM USERS" +
                " WHERE login = '%s'", login);
        try {
            int myHash = pass.hashCode();

            ResultSet rs = stmt.executeQuery(sql);

            if(rs.next()) {
                String nick = rs.getString(1);
                int dbHash = rs.getInt(2);

                if(myHash == dbHash) {
                    return nick;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    public static void disconnect() {
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
