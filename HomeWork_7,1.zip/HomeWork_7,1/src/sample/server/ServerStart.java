package sample.server;

import java.sql.SQLException;

public class ServerStart {
    public static void main(String[] args) throws SQLException {
        new MainServer();
    }
}
