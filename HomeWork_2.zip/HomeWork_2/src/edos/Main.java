package edos;

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Main {

    public static void main(String[] args) {
        testArray();
    }

    public static void testArray() {
        Array array = new Array();
        Array array2 = new Array();
        Array array3 = new Array();
        Random random = new Random();
        for (int i = 0, j; i < array.getCAPACITY(); i++) {
            array.add(j = random.nextInt(100));
            array2.add(j);
            array3.add(j);
        }

//        System.out.println(array);
//        System.out.println(array2);
//        System.out.println(array3);

        long start = System.nanoTime();
        array.sortBubble();
        long finish = System.nanoTime();
        long delta = finish - start;
        System.out.println("Время сортировки методом sortBubble: " + TimeUnit.NANOSECONDS.toMillis(delta) + "мс");

        long start2 = System.nanoTime();
        array.sortSelect();
        long finish2 = System.nanoTime();
        long delta2 = finish2 - start2;
        System.out.println("Время сортировки методом sortSelect: " + TimeUnit.NANOSECONDS.toMillis(delta2) + "мс");

        long start3 = System.nanoTime();
        array.sortInsert();
        long finish3 = System.nanoTime();
        long delta3 = finish3 - start3;
        System.out.println("Время сортировки методом sortInsert: " + TimeUnit.NANOSECONDS.toMillis(delta3) + "мс");
    }
}
