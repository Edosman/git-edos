package edos;

public interface IFaceForArray {

    void add(int value);

    boolean remove(int value);

    boolean find(int value);

    void sortBubble();

    void sortSelect();

    void sortInsert();
}
